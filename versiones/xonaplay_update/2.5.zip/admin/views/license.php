<?php include(__DIR__ . '/header.php'); ?>
				<div class="container-fluid">
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title">License</h3>
						</div>
						<form method="post" action="<?php echo $mvctemplate['url']; ?>/?do=license">
							<div class="panel-body">
								<div class="row">
								<?php if(!empty($mvctemplate['stack']['options']['license_key'])) { ?>
								<div class="col-lg-12 col-md-12">
											<div class="form-group">
												<label class="control-label">Status:</label>
			                                <font style="color:green;">Activo</font>
											</div>
								</div>	
								
								<div class="col-lg-12 col-md-12">
											<div class="form-group">
												<label class="control-label">Actualizacion:</label>
												<font style="color:green;"><?php echo date('d-m-Y', strtotime($mvctemplate['stack']['options']['updates'])); ?></font>
											</div>
								</div>
								
								<div class="col-lg-12 col-md-12">
											<div class="form-group">
												<label class="control-label">Soporte:</label>
												<font style="color:green;"><?php echo date('d-m-Y', strtotime($mvctemplate['stack']['options']['support'])); ?></font>
											</div>
								</div>
								
								<div class="col-lg-12 col-md-12">
											<div class="form-group">
												<label class="control-label">Expira:</label>
												<font style="color:green;"><?php echo date('d-m-Y', strtotime($mvctemplate['stack']['options']['expiracion'])); ?></font>
											</div>
								</div>
								<?php } ?>
										
										<div class="col-lg-12 col-md-12">
											<div class="form-group">
												<label class="control-label">License Key:</label>
												<input type="text" class="form-control" name="license_key" value="<?php echo $mvctemplate['stack']['options']['license_key']; ?>"><br>
											</div>
										</div>																				
										
									  
										
										
										
								</div>
							</div>
							<div class="panel-footer">
								<button type="submit" name="guardar_licencia" class="btn btn-info">EDIT LICENSE</button>
							</div>
						</form>
					</div>
<?php include(__DIR__  . '/footer.php'); ?>