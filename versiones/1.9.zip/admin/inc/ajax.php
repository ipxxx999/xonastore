<?php 
include '../header.php';

if(user::isAdmin()){
$id = trim(strip_tags($_POST['id']));

if(!is_numeric($id)) return;
$medb = get_connect_db();
$actualizar_link = $medb->query("UPDATE links SET status = '0', error = '', ubicacion = '', calidades = '', views = '0' WHERE id = '$id'");
echo $actualizar_link;
}





?>