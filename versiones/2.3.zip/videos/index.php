<?php 
	//Silence is gold
?>